<!-- Start Footer -->
  	<div class="row">
  	<div class="main_footer">
         <div class="row">
            <div class="col-md-9 col-sm-8 col-xs-12">lb college <?php echo date(Y); ?>  <a href="https://en.wikipedia.org/wiki/Dr.L.Bullayya_College" style="text-decoration:none; color:#FF0;" target="_blank"> lb college </a>. </div>
            <div class="col-md-3 col-sm-4 col-xs-12" align="center">Designed by <a href="http://www.freetimelearning.com" style="text-decoration:none; color:#FF0;" target="_blank"> LAVANYA,Alekhya,Bhanu </a>.</div>
         </div>
    </div>
  </div>  
<!-- End Footer -->